package jx

//go:generate go run ./tools/mkint
