package baz

type Test string
