package decimal

type Decimal string
