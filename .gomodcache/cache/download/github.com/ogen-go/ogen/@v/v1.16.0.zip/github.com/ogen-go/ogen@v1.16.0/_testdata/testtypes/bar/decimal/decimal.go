package decimal

type Decimal float64
