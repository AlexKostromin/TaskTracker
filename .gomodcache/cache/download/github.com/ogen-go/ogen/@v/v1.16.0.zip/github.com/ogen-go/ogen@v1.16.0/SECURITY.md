# Security Policy

Use [GitHub Security Reporting][reporting] to report security vulnerabilities under the "Security" section.

[reporting]: https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability#privately-reporting-a-security-vulnerability
