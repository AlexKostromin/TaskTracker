// Package gen contains the code generator for OpenAPI Spec.
package gen
