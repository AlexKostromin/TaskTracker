// Package ir contains definitions for the intermediate representation of OpenAPI objects and generated Go types.
package ir
