// Package conv contains helper functions for converting between various data types.
package conv
