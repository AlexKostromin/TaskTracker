// Package httpcookie contains some utilities to validate cookie values.
package httpcookie
